<?php
$locale_arr = array (
"language" => "Spanish",
"template" => array (
        // Maintenance Buttons
        "T_GO_BACK" => "Volver",
        "T_NO_DATA_FOUND" => "No se encontraron datos que coincidan con sus criterios",
        "T_UNABLE_TO_CONTINUE" => "Incapaz de Seguir",
        "T_INFORMATION" => "Información",
        "T_GO_REFRESH" => "Refrescar",
        "T_GO_PRINT" => "Imprimir",
)
);
?>
