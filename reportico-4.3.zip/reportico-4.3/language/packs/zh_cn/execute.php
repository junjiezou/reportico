<?php
$locale_arr = array (
"language" => "Chinese (simplified)",
"template" => array (
        // Maintenance Buttons
		"T_GO_BACK" => "返回",
		"T_NO_DATA_FOUND" => "未找到数据匹配您的标准",
		"T_UNABLE_TO_CONTINUE" => "无法继续",
		"T_INFORMATION" => "信息",
        "T_GO_REFRESH" => "刷新",
        "T_GO_PRINT" => "打印",
        )
);
?>
