<?php
$locale_arr = array (
    "language" => "English",
    "template" => array (
        "T_CHOOSE_LANGUAGE" => "Choose Language",
        "T_GO" => "Go",
        "T_LOGGED_IN_AS" => "Logged in as",
        "T_LOGIN" => "Log In",
        "T_LOGOFF" => "Log Off",
        "T_ADMIN_HOME" => "Admin Home Page",
        "T_CONFIG_PROJECT" => "Configure Project",
        "T_CREATE_REPORT" => "Create Report",
        "T_ENTER_PROJECT_PASSWORD" => "Enter the project password.",
        "T_ENTER_PROJECT_PASSWORD_DEMO" => "Enter the project password. <br>The password for these tutorials is <b>reportico</b>",
        "T_UNABLE_TO_CONTINUE" => "Unable To Continue",
        "T_PASSWORD_ERROR" => "Incorrect Password. Try again.",
        ),
        );
?>
